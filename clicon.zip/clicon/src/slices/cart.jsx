import { createSlice } from "@reduxjs/toolkit";
import AllData from "../../public/data/AllData";

const initialState = {
  data : AllData,
  inCart : []
}

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addCart(state, action) {
      state.inCart.push(action.payload)
    },
    deleteCart(state, action) {
      state.inCart.splice(action.payload, 1)
    },
    updateCart(state, action) {},
  },
});

export const { addCart, deleteCart, updateCart } = cartSlice.actions;

export default cartSlice.reducer;
